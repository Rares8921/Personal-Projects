package sample;

public class Open {
    public static void main(String[] args) {
        sample.Main.main(args);
    }
}
